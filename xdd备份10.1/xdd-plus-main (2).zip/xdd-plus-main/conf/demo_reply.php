return reply(
     [
          `早上好`=>`good morning`
          `扫码` => `扫个锤子，看公告`
          `你好`=> `我还行`
          `美腿` => `https://api.iyk0.com/mtt`
          `毒鸡汤`=>`https://www.hlapi.cn/api/djt?charset=utf-8&encode=text`
          `笑话`=>`https://www.hlapi.cn/api/gxdz`
          `妹妹` => `https://3650000.xyz/api/`
          `精神语录`=>`https://api.xcboke.cn/api/yulu?c=1002&encode=text`
          `网抑云`=>`https://api.xcboke.cn/api/yulu?c=1003&encode=text`
          `朋友圈文案`=>`https://api.xcboke.cn/api/yulu?c=1008&encode=text`
          `.*来对线`=>`https://api.xcboke.cn/api/yulu?c=1009&encode=text`
          `动漫台词`=>`https://api.xcboke.cn/api/yulu?c=2001&encode=text`
          `游戏台词`=>`https://api.xcboke.cn/api/yulu?c=2003&encode=text`
          `壁纸` => `http://api.btstu.cn/sjbz/?lx=dongman`
          `小清新` => `http://api.btstu.cn/sjbz/?lx=meizi`
          `.*美女` => `https://api.lyiqk.cn/purelady`
         `二次元图` => `https://acg.toubiec.cn/random.php`
         `.*换一个` => `http://api.btstu.cn/sjbz/?lx=m_dongman`
         `动漫头像` => `http://shengapi.cn/api/image/acgtx.php`
         `舔狗日记` => `http://shengapi.cn/api/tgrj.php`
         `.*骚话.*`=>`https://api.vvhan.com/api/sao`
         `文明` => `http://api.btstu.cn/sjbz/zsy.php`
          `富强` => `http://api.btstu.cn/sjbz/?m_lx=suiji`
          `和谐` => `https://api.btstu.cn/sjbz/api.php`
          `民主` => `https://cdn.seovx.com/?mom=302`
          `语录` => `https://api.ixiaowai.cn/ylapi/index.php`
          `舔狗` => `https://api.ixiaowai.cn/tgrj/index.php`
	  `.*一言.*`=>`https://api.ixiaowai.cn/ylapi/index.php`
`说明`=>`https://ghproxy.com/https://raw.githubusercontent.com/U188/JDC/master/sm.jpg`
`咨询`=>`https://ghproxy.com/https://raw.githubusercontent.com/U188/JDC/master/zx.png`
        `密码` => `你猜`
        `菜单` => `
                京东菜单
       ———————————
            说明  丨  咨询
            打卡  丨  余额
            许愿
       ———————————
                娱乐菜单
       ———————————
            富强  丨 民主
            文明  丨 和谐
            妹妹  丨 美女
            风景  丨 壁纸
            你好  丨 美腿
            状态  丨 笑话
            骚话  丨 对线
       精神语录丨 毒鸡汤
       动漫台词丨 朋友圈文案
      ———————————
              管理员菜单
      ———————————
            状态  丨 升级
            重启  丨 转账
            删除  丨 通知
            执行  丨 优先级
            绑定  丨 命令
            导出  丨 助力
            回复  丨 屏蔽
            更新账号 |  清理过期账号
            取消屏蔽 |  任务列表
            设置管理员 | 取消管理员
      ———————————
              京东机器人`
        ]
)
